let tab = "hoy";
let toast = null;
let confirmRedeem = null;

const TABS = [
  ["hoy", "Hoy"],
  ["plan", "Plan"],
  ["sos", "SOS"],
  ["premios", "Premios"],
  ["patrones", "Patrones"],
  ["ajustes", "Ajustes"]
];

// ---- cálculos ----

function getStats(now = Date.now()) {
  const elapsed = now - state.quitAt;
  const sinceQuit = events.filter(e => e.at >= state.quitAt);
  const smoked = sinceQuit.filter(e => e.outcome === "fume").length;
  const won = sinceQuit.filter(e => e.outcome === "superado").length;
  const days = Math.max(0, elapsed) / DAY;
  const expected = Math.floor(days * state.cigsPerDay);
  const avoided = Math.max(0, expected - smoked);
  const saved = avoided / state.packSize * state.packPrice;
  return { elapsed, days, smoked, won, avoided, saved };
}

function getRewards() {
  const list = state.rewards || [];
  const done = list.filter(r => r.redeemedAt);
  const spent = done.reduce((sum, r) => sum + r.price, 0);
  return {
    list,
    done,
    spent,
    pending: list.filter(r => !r.redeemedAt && !r.removedAt),
    removed: list.filter(r => r.removedAt && !r.redeemedAt),
    available: Math.max(0, getStats().saved - spent),
    perDay: state.cigsPerDay / state.packSize * state.packPrice
  };
}

function daysLeftText(missing, perDay) {
  const d = Math.ceil(missing / perDay);
  return d <= 1 ? "1 día más sin fumar" : d + " días más sin fumar";
}

// ---- render ----

function render() {
  renderTabs();
  const app = $("#app");

  if (!state) {
    app.innerHTML = setupView();
    return;
  }

  const views = {
    hoy: todayView,
    plan: planView,
    premios: rewardsView,
    patrones: patternsView,
    ajustes: settingsView
  };
  app.innerHTML = (views[tab] || todayView)();
  tick();
}

function renderTabs() {
  const nav = $("#tabs");
  nav.hidden = !state;
  if (!state) return;

  nav.innerHTML = TABS.map(([key, label]) => `
    <button data-tab="${key}" class="${key === "sos" ? "tab-sos" : ""}" ${tab === key ? 'aria-current="page"' : ""}>
      ${ICONS[key]}<span>${label}</span>
    </button>`).join("");
}

function showToast(text, slip = false, ms = 4000) {
  toast = { text, slip };
  tab = "hoy";
  render();
  setTimeout(() => {
    toast = null;
    if (tab === "hoy") render();
  }, ms);
}

// contador de tiempo sin fumar
function tick() {
  const el = $("#clock");
  if (!el || !state) return;

  const ms = Math.abs(Date.now() - state.quitAt);
  const d = Math.floor(ms / DAY);
  const h = Math.floor(ms / HOUR) % 24;
  const m = Math.floor(ms / 60000) % 60;
  const s = Math.floor(ms / 1000) % 60;
  el.innerHTML = `${d}<small>d</small>${pad(h)}<small>h</small>${pad(m)}<small>m</small>${pad(s)}<small>s</small>`;
}

// ---- pantallas ----

function setupView() {
  return `
  <div class="hero">
    <p class="label">Rewiro · Día cero</p>
    <h1>Vamos a dejarlo, empezando ya.</h1>
    <p class="muted">Cuatro datos y arrancamos. Puedes cambiarlos después en Ajustes.</p>
  </div>
  <form class="card" id="setup">
    <div class="field">
      <label class="label" for="s-quit">Mi corte empieza</label>
      <input id="s-quit" type="datetime-local" value="${toInputValue(nextMidnight())}" required>
      <div class="row"><button type="button" class="ghost small" id="s-now">Ahora mismo</button></div>
    </div>
    <div class="grid2">
      <div class="field">
        <label class="label" for="s-cpd">Cigarros al día</label>
        <input id="s-cpd" type="number" min="1" max="80" value="20" inputmode="numeric">
      </div>
      <div class="field">
        <label class="label" for="s-price">Precio cajetilla</label>
        <input id="s-price" type="number" min="1" value="90" inputmode="decimal">
      </div>
    </div>
    <div class="field">
      <label class="label" for="s-why">Por qué lo dejo</label>
      <textarea id="s-why" placeholder="Escríbelo con tus palabras. Lo vas a leer en cada antojo."></textarea>
    </div>
    <button class="primary full" type="submit">Empezar</button>
    <p class="note">Tus datos se guardan solo en este navegador.</p>
  </form>`;
}

function todayView() {
  const s = getStats();
  const notStarted = s.elapsed < 0;

  const idx = MILESTONES.findIndex(m => s.elapsed < m.hours * HOUR);
  const next = idx >= 0 ? MILESTONES[idx] : null;
  const prevHours = idx > 0 ? MILESTONES[idx - 1].hours : 0;
  const progress = next
    ? Math.min(100, Math.max(0, (s.elapsed / HOUR - prevHours) / (next.hours - prevHours) * 100))
    : 100;

  const inPack = s.avoided % state.packSize;
  const packs = Math.floor(s.avoided / state.packSize);
  let sticks = "";
  for (let i = 0; i < state.packSize; i++) {
    sticks += `<i class="stick ${i < inPack ? "on" : ""}"></i>`;
  }

  return `
  ${toast ? `<div class="toast ${toast.slip ? "slip" : ""}" role="status">${esc(toast.text)}</div>` : ""}
  <div class="hero">
    <p class="label">${notStarted ? "Tu corte empieza en" : "Sin fumar desde " + esc(formatWhen(state.quitAt))}</p>
    <div class="clock" id="clock"></div>
  </div>

  <button class="sos-btn" data-act="sos">
    Tengo un antojo
    <span>Abre el botón SOS. El antojo baja en unos minutos.</span>
  </button>

  <div class="grid2">
    <div class="stat"><span class="label">No fumados</span><b>${s.avoided}</b></div>
    <div class="stat"><span class="label">Ahorrado</span><b>${money(s.saved)}</b></div>
    <div class="stat"><span class="label">Antojos vencidos</span><b>${s.won}</b></div>
    <div class="stat"><span class="label">Deslices</span><b>${s.smoked}</b></div>
  </div>

  <section class="card">
    <div class="row between">
      <h3>Cajetilla que no compraste</h3>
      <span class="num muted small">${packs} completas</span>
    </div>
    <div class="pack" aria-label="${inPack} de ${state.packSize} cigarros de la cajetilla actual">${sticks}</div>
    <p class="small muted">Cada barra es un cigarro que no fumaste. Al llenar ${state.packSize}, sumas una cajetilla.</p>
  </section>

  ${next ? `
  <section class="card">
    <p class="label">Lo que tu cuerpo está recuperando</p>
    <h3>${esc(next.text)}</h3>
    <div class="bar"><i style="width:${progress.toFixed(1)}%"></i></div>
  </section>` : ""}

  ${nextRewardCard()}

  ${state.reasons ? `
  <section class="card">
    <p class="label">Por qué lo dejo</p>
    <p>${esc(state.reasons)}</p>
  </section>` : ""}

  <button class="ghost full" data-act="slip">Fumé uno · registrarlo</button>`;
}

function nextRewardCard() {
  const R = getRewards();

  if (!R.pending.length) {
    return `
    <section class="card">
      <p class="label">Premios</p>
      <h3>¿Qué te vas a comprar con lo que ahorras?</h3>
      <button data-tab="premios">Agregar un premio</button>
    </section>`;
  }

  // el más barato es el más cercano
  const r = [...R.pending].sort((a, b) => a.price - b.price)[0];
  const pct = Math.min(100, R.available / r.price * 100);
  const missing = r.price - R.available;

  return `
  <section class="card">
    <div class="row between">
      <p class="label">Próximo premio</p>
      ${missing <= 0 ? '<span class="badge">Listo</span>' : ""}
    </div>
    <h3>${esc(r.name)}</h3>
    <div class="bar"><i style="width:${pct.toFixed(1)}%"></i></div>
    <p class="small">
      ${missing <= 0
        ? "Ya juntaste lo suficiente. Puedes canjearlo."
        : `<span class="num">${money(R.available)}</span> de <span class="num">${money(r.price)}</span> · faltan ${daysLeftText(missing, R.perDay)}`}
    </p>
    ${R.done.length ? `<p class="small muted">Ya te has comprado <b>${R.done.length}</b> ${plural(R.done.length, "cosa", "cosas")} sin fumar (<span class="num">${money(R.spent)}</span>).</p>` : ""}
    <button data-tab="premios">Ver mis premios</button>
  </section>`;
}

function rewardCard(r, R) {
  const pct = Math.min(100, R.available / r.price * 100);
  const missing = r.price - R.available;
  const ready = missing <= 0;

  let actions;
  if (confirmRedeem === r.id) {
    actions = `
      <p class="small">¿Canjear <b>${esc(r.name)}</b>? Se restan <span class="num">${money(r.price)}</span> de tu ahorro disponible.</p>
      <div class="row">
        <button class="primary" data-redeem-yes="${r.id}">Sí, me lo gané</button>
        <button data-redeem-no="1">Cancelar</button>
      </div>`;
  } else {
    actions = `
      <div class="row">
        ${ready ? `<button class="primary" data-redeem="${r.id}">Canjear</button>` : ""}
        <button class="ghost small" data-del-reward="${r.id}">Quitar</button>
      </div>`;
  }

  return `
  <div class="reward ${ready ? "ready" : ""}">
    <div class="reward-top"><h3>${esc(r.name)}</h3><span class="num">${money(r.price)}</span></div>
    <div class="bar"><i style="width:${pct.toFixed(1)}%"></i></div>
    <p class="small">${ready
      ? "<b>Ya te alcanza.</b> Te lo ganaste."
      : `Te faltan <span class="num">${money(missing)}</span> · ${daysLeftText(missing, R.perDay)}`}</p>
    ${actions}
  </div>`;
}

function rewardsView() {
  const R = getRewards();

  const pending = R.pending.map(r => rewardCard(r, R)).join("");

  const done = [...R.done]
    .sort((a, b) => b.redeemedAt - a.redeemedAt)
    .map(r => {
      const when = typeof r.daysFree === "number"
        ? ` · a los ${r.daysFree} ${plural(r.daysFree, "día", "días")} sin fumar`
        : "";
      return `<li>
        <span><b>${esc(r.name)}</b><br><span class="small muted">${esc(formatDate(r.redeemedAt))}${when}</span></span>
        <span class="num">${money(r.price)}</span>
      </li>`;
    }).join("");

  const removed = [...R.removed]
    .sort((a, b) => b.removedAt - a.removedAt)
    .map(r => `<li>
      <span>${esc(r.name)}<br><span class="small muted">Quitado el ${esc(formatDate(r.removedAt))}</span></span>
      <span class="row"><span class="num muted">${money(r.price)}</span><button class="ghost small" data-restore="${r.id}">Volver a agregar</button></span>
    </li>`).join("");

  return `
  <div class="hero">
    <p class="label">Premios</p>
    <h1>Lo que te estás ganando.</h1>
    <p class="muted">Cada premio se paga con el dinero que dejas de gastar en cigarros.</p>
  </div>

  <div class="grid2">
    <div class="stat"><span class="label">Disponible</span><b>${money(R.available)}</b></div>
    <div class="stat"><span class="label">Ahorras al día</span><b>${money(R.perDay)}</b></div>
  </div>

  ${done ? `
  <section class="card">
    <p class="label">Mi baúl</p>
    <h2>Lo que me he comprado sin fumar</h2>
    <div class="grid2">
      <div class="stat"><span class="label">Premios ganados</span><b>${R.done.length}</b></div>
      <div class="stat"><span class="label">Invertido en mí</span><b>${money(R.spent)}</b></div>
    </div>
    <p>${esc(CHEERS[Math.min(R.done.length, CHEERS.length) - 1])}</p>
    <ul class="done-list">${done}</ul>
  </section>` : ""}

  ${pending ? `
  <section class="card">
    <h3>En camino</h3>
    ${pending}
    <p class="note">Todos los premios comparten tu ahorro: al canjear uno, su precio se resta del disponible.</p>
  </section>` : ""}

  <section class="card">
    <h3>Agregar un premio</h3>
    <form id="add-reward" class="stack">
      <div class="field">
        <label class="label" for="r-name">Qué quiero</label>
        <input id="r-name" required maxlength="80" placeholder="Ej. teclado mecánico, audífonos, un viaje">
      </div>
      <div class="field">
        <label class="label" for="r-price">Cuánto cuesta (MXN)</label>
        <input id="r-price" type="number" min="1" required inputmode="decimal" placeholder="Ej. 650">
      </div>
      <button class="primary" type="submit">Agregar premio</button>
    </form>
  </section>

  ${removed ? `
  <section class="card">
    <details>
      <summary class="label" style="cursor:pointer">Historial de premios quitados (${R.removed.length})</summary>
      <ul class="done-list" style="margin-top:10px">${removed}</ul>
    </details>
  </section>` : ""}`;
}

function reasonsForm() {
  return `
  <section class="card">
    <h3>Por qué lo dejo</h3>
    <form id="why" class="field">
      <textarea id="w-text" aria-label="Por qué lo dejo">${esc(state.reasons || "")}</textarea>
      <button class="primary" type="submit">Guardar</button>
    </form>
  </section>`;
}

function planView() {
  const plans = state.plans || [];
  const rows = plans.map((p, i) => `
    <div class="plan-row">
      <p><b>Si ${esc(triggerName(p.trigger).toLowerCase())}</b>, entonces ${esc(p.action)}</p>
      <button class="ghost small" data-del-plan="${i}">Quitar</button>
    </div>`).join("");

  return `
  <div class="hero">
    <p class="label">Plan</p>
    <h1>Decide ahora, no en el antojo.</h1>
  </div>

  <section class="card">
    <h3>Si pasa esto… hago esto</h3>
    <div class="stack">${rows || '<p class="muted">Aún no hay planes. Agrega el primero abajo.</p>'}</div>
    <form id="add-plan" class="stack">
      <div class="field">
        <label class="label" for="p-trigger">Si…</label>
        <select id="p-trigger">${TRIGGERS.map(t => `<option value="${t.key}">${esc(t.name)}</option>`).join("")}</select>
      </div>
      <div class="field">
        <label class="label" for="p-action">Entonces…</label>
        <input id="p-action" required placeholder="Qué vas a hacer en lugar de fumar">
      </div>
      <button class="primary" type="submit">Agregar plan</button>
    </form>
  </section>

  ${reasonsForm()}

  <section class="card">
    <p class="label">Apoyo médico</p>
    <h3>Combinar esto con tratamiento aumenta mucho tus probabilidades.</h3>
    <p class="small">Los sustitutos de nicotina (parches, chicles) y algunos medicamentos con receta ayudan con la abstinencia. Un médico puede decirte cuál te conviene.</p>
    <label class="row small">
      <input type="checkbox" id="med" ${state.medAppt ? "checked" : ""}>
      Ya agendé o pedí una cita médica para esto
    </label>
    <p class="small">Orientación gratuita en México, Línea de la Vida:</p>
    <div class="copy"><code id="tel">800 911 2000</code><button class="small" data-act="copy-tel">Copiar</button></div>
  </section>`;
}

function patternsView() {
  if (!events.length) {
    return `
    <div class="hero">
      <p class="label">Patrones</p>
      <h1>Aquí vas a ver qué te detona.</h1>
    </div>
    <section class="card">
      <p>Cada vez que uses el botón SOS o registres un desliz, aparecerá aquí: a qué hora te dan los antojos, qué los provoca y cuántos vences.</p>
      <button class="primary" data-act="sos">Registrar mi primer antojo</button>
    </section>`;
  }

  const byTrigger = {};
  const byHour = Array(24).fill(0);
  let wins = 0, intensitySum = 0, intensityCount = 0;

  for (const e of events) {
    byTrigger[e.trigger] = (byTrigger[e.trigger] || 0) + 1;
    byHour[new Date(e.at).getHours()]++;
    if (e.outcome === "superado") wins++;
    if (e.intensity) {
      intensitySum += e.intensity;
      intensityCount++;
    }
  }

  const maxTrigger = Math.max(...Object.values(byTrigger));
  const maxHour = Math.max(...byHour);
  const peak = byHour.indexOf(maxHour);

  const triggerRows = Object.entries(byTrigger)
    .sort((a, b) => b[1] - a[1])
    .map(([key, n]) => `
      <div class="hbar">
        <span>${esc(triggerName(key))}</span>
        <span class="track"><i style="width:${n / maxTrigger * 100}%"></i></span>
        <span class="num">${n}</span>
      </div>`).join("");

  const hourBars = byHour.map(n => {
    const h = n ? Math.max(6, n / maxHour * 100) : 3;
    return `<i class="${n ? "" : "zero"}" style="height:${h}%" title="${n}"></i>`;
  }).join("");

  const log = events.slice(0, 30).map(e => `
    <li>
      <span class="pill ${e.outcome === "superado" ? "ok" : "no"}">${e.outcome === "superado" ? "Vencido" : "Fumé"}</span>
      <span>${esc(triggerName(e.trigger))}${e.intensity ? ` · intensidad ${e.intensity}` : ""}</span>
      <span class="small muted num">${esc(formatWhen(e.at))}</span>
    </li>`).join("");

  return `
  <div class="hero">
    <p class="label">Patrones</p>
    <h1>Tu antojo tiene horario.</h1>
  </div>

  <div class="grid2">
    <div class="stat"><span class="label">Vencidos</span><b>${Math.round(wins / events.length * 100)}%</b></div>
    <div class="stat"><span class="label">Intensidad media</span><b>${intensityCount ? (intensitySum / intensityCount).toFixed(1) : "—"}</b></div>
  </div>

  <section class="card"><h3>Qué los detona</h3>${triggerRows}</section>

  <section class="card">
    <h3>A qué hora</h3>
    <div class="hours" aria-label="Antojos por hora del día">${hourBars}</div>
    <div class="hour-labels num"><span>0 h</span><span>6 h</span><span>12 h</span><span>18 h</span></div>
    <p class="small">Tu hora más difícil: <b class="num">${pad(peak)}:00–${pad((peak + 1) % 24)}:00</b>. Ten tu plan listo antes de esa hora.</p>
  </section>

  <section class="card"><h3>Registro</h3><ul class="log">${log}</ul></section>`;
}

function settingsView() {
  return `
  <div class="hero">
    <p class="label">Ajustes</p>
    <h1>Tus números.</h1>
  </div>

  <form class="card" id="settings">
    <div class="field">
      <label class="label" for="a-quit">Fecha y hora de corte</label>
      <input id="a-quit" type="datetime-local" value="${toInputValue(state.quitAt)}">
    </div>
    <div class="grid2">
      <div class="field">
        <label class="label" for="a-cpd">Cigarros al día (antes)</label>
        <input id="a-cpd" type="number" min="1" max="80" value="${state.cigsPerDay}">
      </div>
      <div class="field">
        <label class="label" for="a-pack">Cigarros por cajetilla</label>
        <input id="a-pack" type="number" min="1" max="40" value="${state.packSize}">
      </div>
    </div>
    <div class="field">
      <label class="label" for="a-price">Precio de la cajetilla (MXN)</label>
      <input id="a-price" type="number" min="1" value="${state.packPrice}">
    </div>
    <button class="primary" type="submit">Guardar</button>
    <p class="note">Tus datos se guardan solo en este navegador.</p>
  </form>

  ${reasonsForm()}

  <section class="card">
    <h3>Reiniciar el corte</h3>
    <p class="small muted">Solo si tú lo decides. Un desliz no obliga a reiniciar: tu registro ya lo cuenta.</p>
    <div id="reset-box"><button data-act="ask-reset">Reiniciar a este momento</button></div>
  </section>`;
}
