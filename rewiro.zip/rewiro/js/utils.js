const $ = (sel, root = document) => root.querySelector(sel);

const ESC_MAP = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ESC_MAP[c]);

const pad = n => String(n).padStart(2, "0");
const money = n => "$" + Math.round(n).toLocaleString("es-MX");

const DAY = 86400000;
const HOUR = 3600000;

// para los <input type="datetime-local">
function toInputValue(ms) {
  const d = new Date(ms);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function fromInputValue(value) {
  const t = new Date(value).getTime();
  return isNaN(t) ? null : t;
}

function nextMidnight() {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

function formatWhen(ms) {
  const d = new Date(ms);
  return d.toLocaleDateString("es-MX", { day: "numeric", month: "short" }) + " · " + pad(d.getHours()) + ":" + pad(d.getMinutes());
}

function formatDate(ms) {
  return new Date(ms).toLocaleDateString("es-MX", { day: "numeric", month: "short", year: "numeric" });
}

function formatCountdown(sec) {
  sec = Math.max(0, sec);
  return Math.floor(sec / 60) + ":" + pad(sec % 60);
}

function plural(n, one, many) {
  return n === 1 ? one : many;
}
