function updateRewards(id, fn) {
  const rewards = (state.rewards || []).map(r => r.id === id ? fn(r) : r);
  saveState({ ...state, rewards });
}

document.addEventListener("click", async ev => {
  const btn = ev.target.closest("button");
  if (!btn) return;
  const d = btn.dataset;

  // navegación
  if (d.tab) {
    if (d.tab === "sos") return openSOS();
    tab = d.tab;
    toast = null;
    render();
    window.scrollTo(0, 0);
    return;
  }

  if (btn.id === "s-now") {
    $("#s-quit").value = toInputValue(Date.now());
    return;
  }

  switch (d.act) {
    case "sos":
    case "slip":
      return openSOS();

    case "copy-tel":
      try {
        await navigator.clipboard.writeText("8009112000");
        btn.textContent = "Copiado";
      } catch (e) {
        const range = document.createRange();
        range.selectNodeContents($("#tel"));
        getSelection().removeAllRanges();
        getSelection().addRange(range);
      }
      return;

    case "ask-reset":
      $("#reset-box").innerHTML = `
        <p class="small">¿Reiniciar tu fecha de corte a este momento?</p>
        <div class="row">
          <button class="danger" data-act="do-reset">Sí, reiniciar</button>
          <button data-act="cancel-reset">Cancelar</button>
        </div>`;
      return;

    case "cancel-reset":
      return render();

    case "do-reset":
      tab = "hoy";
      return saveState({ ...state, quitAt: Date.now() });
  }

  // planes
  if (d.delPlan !== undefined) {
    const plans = [...(state.plans || [])];
    plans.splice(Number(d.delPlan), 1);
    return saveState({ ...state, plans });
  }

  // premios
  if (d.redeem) {
    confirmRedeem = d.redeem;
    return render();
  }
  if (d.redeemNo) {
    confirmRedeem = null;
    return render();
  }
  if (d.redeemYes) {
    confirmRedeem = null;
    const daysFree = Math.max(0, Math.floor(getStats().days));
    return updateRewards(d.redeemYes, r => ({ ...r, redeemedAt: Date.now(), daysFree }));
  }
  if (d.delReward) {
    return updateRewards(d.delReward, r => ({ ...r, removedAt: Date.now() }));
  }
  if (d.restore) {
    return updateRewards(d.restore, r => {
      const copy = { ...r };
      delete copy.removedAt;
      return copy;
    });
  }

  // SOS
  if (d.trigger) {
    sos.trigger = d.trigger;
    return drawSOS();
  }
  if (d.intensity) {
    sos.intensity = Number(d.intensity);
    return drawSOS();
  }

  switch (d.sos) {
    case "close": return closeSOS();
    case "start": return startBreathing();
    case "won": return finishSOS("superado");
    case "lost": return finishSOS("fume");
    case "slip-now":
      if (!sos.trigger) sos.trigger = "habito";
      return finishSOS("fume");
  }
});

document.addEventListener("change", ev => {
  if (ev.target.id === "med") {
    saveState({ ...state, medAppt: ev.target.checked });
  }
});

document.addEventListener("submit", ev => {
  ev.preventDefault();
  const id = ev.target.id;

  if (id === "setup") {
    tab = "hoy";
    saveState({
      quitAt: fromInputValue($("#s-quit").value) || nextMidnight(),
      cigsPerDay: Math.max(1, Number($("#s-cpd").value) || 20),
      packPrice: Math.max(1, Number($("#s-price").value) || 90),
      packSize: 20,
      reasons: $("#s-why").value.trim(),
      plans: DEFAULT_PLANS,
      rewards: [],
      medAppt: false,
      createdAt: Date.now()
    });
  }

  else if (id === "add-plan") {
    const action = $("#p-action").value.trim();
    if (!action) return;
    const plan = { trigger: $("#p-trigger").value, action };
    saveState({ ...state, plans: [...(state.plans || []), plan] });
  }

  else if (id === "add-reward") {
    const name = $("#r-name").value.trim();
    const price = Number($("#r-price").value);
    if (!name || !(price > 0)) return;
    const reward = { id: Date.now().toString(36), name, price, createdAt: Date.now() };
    saveState({ ...state, rewards: [...(state.rewards || []), reward] });
  }

  else if (id === "why") {
    saveState({ ...state, reasons: $("#w-text").value.trim() });
    showToast("Guardado.");
  }

  else if (id === "settings") {
    saveState({
      ...state,
      quitAt: fromInputValue($("#a-quit").value) || state.quitAt,
      cigsPerDay: Math.max(1, Number($("#a-cpd").value) || state.cigsPerDay),
      packSize: Math.max(1, Number($("#a-pack").value) || state.packSize),
      packPrice: Math.max(1, Number($("#a-price").value) || state.packPrice)
    });
    showToast("Ajustes guardados.");
  }
});

setInterval(tick, 1000);
loadData();
render();
