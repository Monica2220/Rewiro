// Detonantes del antojo y qué hacer con cada uno
const TRIGGERS = [
  { key: "estres", name: "Estrés / ansiedad", tips: [
    "Respira con el círculo: 4 segundos dentro, 6 fuera.",
    "Escribe en una línea qué te está estresando ahora mismo.",
    "Suelta los hombros y aprieta-suelta los puños 5 veces."
  ]},
  { key: "cafe", name: "Café", tips: [
    "Cambia de taza o de lugar donde lo tomas.",
    "Termina el café antes de que llegue el momento de siempre.",
    "Ten un chicle sin azúcar o algo crujiente a la mano."
  ]},
  { key: "comida", name: "Después de comer", tips: [
    "Levántate de la mesa en cuanto termines.",
    "Lávate los dientes: el sabor a menta corta el antojo.",
    "Sal a caminar 5 minutos."
  ]},
  { key: "aburrimiento", name: "Aburrimiento", tips: [
    "Camina 5 minutos, aunque sea dentro de casa.",
    "Manda un mensaje a alguien.",
    "Ocupa las manos: una pluma, un popote, algo que girar."
  ]},
  { key: "social", name: "Con gente / alcohol", tips: [
    "Aléjate de donde están fumando.",
    "Ten agua mineral o algo en la mano.",
    "Dilo en voz alta: “ya no fumo”."
  ]},
  { key: "emocion", name: "Enojo / tristeza", tips: [
    "Ponle nombre a lo que sientes: “estoy enojada porque…”.",
    "Toma agua despacio.",
    "El cigarro no resuelve lo que sientes; solo lo pospone 5 minutos."
  ]},
  { key: "despertar", name: "Al despertar", tips: [
    "Cambia el orden de tu rutina: báñate primero.",
    "Toma un vaso de agua apenas te levantes.",
    "No dejes cigarros ni encendedor cerca de la cama."
  ]},
  { key: "habito", name: "Por costumbre", tips: [
    "Detente 10 segundos y pregúntate: ¿lo quiero o es inercia?",
    "Cambia de cuarto o de actividad.",
    "Ocupa las manos y la boca: zanahoria, pepino, chicle."
  ]}
];

const TRIGGER_BY_KEY = Object.fromEntries(TRIGGERS.map(t => [t.key, t]));

function triggerName(key) {
  return TRIGGER_BY_KEY[key] ? TRIGGER_BY_KEY[key].name : key;
}

// horas sin fumar -> qué pasa en el cuerpo
const MILESTONES = [
  { hours: 1 / 3, text: "20 minutos: tu frecuencia cardiaca y presión empiezan a bajar." },
  { hours: 12, text: "12 horas: el monóxido de carbono en tu sangre baja a lo normal." },
  { hours: 72, text: "3 días: la nicotina sale del cuerpo. Suelen ser los días más duros: aguanta." },
  { hours: 24 * 14, text: "2 semanas: mejoran la circulación y la función pulmonar (2 a 12 semanas)." },
  { hours: 24 * 30, text: "1 mes: empiezan a bajar la tos y la falta de aire (1 a 9 meses)." },
  { hours: 24 * 365, text: "1 año: tu riesgo de enfermedad coronaria baja a la mitad." },
  { hours: 24 * 365 * 5, text: "5 años: tu riesgo de derrame cerebral se reduce mucho (5 a 15 años)." },
  { hours: 24 * 365 * 10, text: "10 años: tu riesgo de cáncer de pulmón baja a la mitad." }
];

const DEFAULT_PLANS = [
  { trigger: "cafe", action: "Café en otra taza y en otro lugar; chicle a la mano." },
  { trigger: "estres", action: "Botón SOS y respirar con el círculo antes de decidir nada." },
  { trigger: "comida", action: "Me levanto de la mesa y me lavo los dientes." }
];

const CHEERS = [
  "Tu primer premio pagado con cigarros que no fumaste. Así se empieza.",
  "Dos premios. Cada uno es una decisión que tomaste en un antojo.",
  "Ya son varios. Esto es lo que el cigarro te estaba quitando.",
  "Mira todo lo que tienes ahora en lugar de humo."
];

const ICONS = {
  hoy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
  plan: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 6h11M9 12h11M9 18h11"/><path d="M4 6l1 1 2-2M4 12l1 1 2-2M4 18l1 1 2-2"/></svg>',
  sos: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3s6 6 6 11a6 6 0 0 1-12 0c0-5 6-11 6-11z"/></svg>',
  premios: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="8" width="18" height="13" rx="2"/><path d="M12 8v13M3 13h18M12 8S10 3 7.5 4.5 9 8 12 8zM12 8s2-5 4.5-3.5S15 8 12 8z"/></svg>',
  patrones: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg>',
  ajustes: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.6-2-3.4-2.4 1a7 7 0 0 0-2-1.2L14 3h-4l-.5 2.6a7 7 0 0 0-2 1.2l-2.4-1-2 3.4 2 1.6A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.6 2 3.4 2.4-1a7 7 0 0 0 2 1.2L10 21h4l.5-2.6a7 7 0 0 0 2-1.2l2.4 1 2-3.4-2-1.6c.1-.4.1-.8.1-1.2z"/></svg>'
};
