// Modo SOS: elegir detonante, 5 minutos de respiración y registrar cómo terminó

const SOS_SECONDS = 300;

// [texto, segundos, escala del círculo]
const BREATH_STEPS = [
  ["Inhala", 4, 1],
  ["Sostén", 2, 1],
  ["Exhala", 6, 0.6]
];

let sos = null;
let sosTimer = null;

function openSOS() {
  sos = { step: 1, trigger: null, intensity: null, left: SOS_SECONDS };
  drawSOS();
  $("#sos").hidden = false;
}

function closeSOS() {
  clearInterval(sosTimer);
  sosTimer = null;
  sos = null;
  $("#sos").hidden = true;
}

function drawSOS() {
  $("#sos").innerHTML = sos.step === 1 ? sosPickView() : sosTimerView();
}

function sosPickView() {
  const chips = TRIGGERS.map(t =>
    `<button class="chip" data-trigger="${t.key}" aria-pressed="${sos.trigger === t.key}">${esc(t.name)}</button>`
  ).join("");

  const dots = [1, 2, 3, 4, 5].map(n =>
    `<button class="num" data-intensity="${n}" aria-pressed="${sos.intensity === n}">${n}</button>`
  ).join("");

  return `
  <div class="wrap">
    <div class="row between">
      <p class="label">SOS</p>
      <button class="ghost small" data-sos="close">Cerrar</button>
    </div>
    <h1>Respira. Esto pasa en minutos.</h1>
    <section class="card">
      <h3>¿Qué lo detonó?</h3>
      <div class="chips">${chips}</div>
    </section>
    <section class="card">
      <h3>¿Qué tan fuerte?</h3>
      <div class="dots">${dots}</div>
      <p class="small muted">1 = leve · 5 = muy fuerte</p>
    </section>
    <button class="primary full" data-sos="start" ${sos.trigger ? "" : "disabled"}>Empezar 5 minutos</button>
    <button class="ghost full" data-sos="slip-now">Ya fumé · solo registrarlo</button>
  </div>`;
}

function sosTimerView() {
  const t = TRIGGER_BY_KEY[sos.trigger];
  const done = sos.left <= 0;

  return `
  <div class="wrap">
    <div class="row between">
      <p class="label">SOS · ${esc(t.name)}</p>
      <button class="ghost small" data-sos="close">Cerrar</button>
    </div>
    <div class="breath" id="breath">
      <div class="breath-text">
        <b class="num" id="sos-left">${formatCountdown(sos.left)}</b>
        <span class="small" id="cue">${done ? "Listo" : "Inhala"}</span>
      </div>
    </div>
    ${done ? '<h2 style="text-align:center">El pico del antojo ya pasó. ¿Cómo terminó?</h2>' : ""}
    <section class="card">
      <p class="label">Haz una de estas</p>
      <ul class="actions">${t.tips.map(x => `<li>${esc(x)}</li>`).join("")}</ul>
    </section>
    ${state.reasons ? `
    <section class="card">
      <p class="label">Por qué lo dejo</p>
      <p>${esc(state.reasons)}</p>
    </section>` : ""}
    <button class="primary full" data-sos="won">Lo superé</button>
    <button class="ghost full" data-sos="lost">Fumé</button>
  </div>`;
}

function startBreathing() {
  sos.step = 2;
  drawSOS();

  let phase = 0;
  let count = 0;
  $("#breath").style.setProperty("--s", "1");

  clearInterval(sosTimer);
  sosTimer = setInterval(() => {
    if (!sos) return;

    sos.left--;
    $("#sos-left").textContent = formatCountdown(sos.left);

    count++;
    if (count >= BREATH_STEPS[phase][1]) {
      count = 0;
      phase = (phase + 1) % BREATH_STEPS.length;
      $("#cue").textContent = BREATH_STEPS[phase][0];
      $("#breath").style.setProperty("--s", String(BREATH_STEPS[phase][2]));
    }

    if (sos.left <= 0) {
      clearInterval(sosTimer);
      sosTimer = null;
      drawSOS();
    }
  }, 1000);
}

function finishSOS(outcome) {
  addEvent({
    at: Date.now(),
    trigger: sos.trigger || "habito",
    intensity: sos.intensity || null,
    outcome
  });
  closeSOS();

  if (outcome === "superado") {
    showToast("Vencido. Cada antojo que pasas sin fumar hace más débil al siguiente.", false, 9000);
  } else {
    showToast("Registrado. Un cigarro no borra tus días: tu fecha de corte sigue igual. Revisa qué lo detonó y ajusta tu plan.", true, 9000);
  }
}
