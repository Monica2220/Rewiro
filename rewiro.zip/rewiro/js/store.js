// Todo se guarda en localStorage, no hay servidor.

const KEY_STATE = "rewiro_state";
const KEY_EVENTS = "rewiro_events";

let state = null;   // configuración, planes y premios
let events = [];    // antojos y deslices, el más reciente primero

function readJSON(key) {
  try {
    return JSON.parse(localStorage.getItem(key));
  } catch (e) {
    return null;
  }
}

function writeJSON(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.warn("No se pudo guardar", key, e);
  }
}

function loadData() {
  state = readJSON(KEY_STATE);
  events = readJSON(KEY_EVENTS) || [];
}

function saveState(next) {
  state = next;
  writeJSON(KEY_STATE, state);
  render();
}

function addEvent(ev) {
  events = [ev, ...events];
  writeJSON(KEY_EVENTS, events);
}
